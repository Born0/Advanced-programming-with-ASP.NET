﻿using Rest_API_with_Db_First.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Rest_API_with_Db_First.Repository
{
    public class ProductRepository : Repository<Product>
    {
    }
}